create function st_distance(text, text)
  returns double precision
immutable
language sql
as $$
SELECT public.ST_Distance($1::public.geometry, $2::public.geometry);
$$;

