create function overlaps_geog(geography, gidx)
  returns boolean
immutable
language sql
as $$
SELECT $2 OPERATOR(public.&&) $1;
$$;

