create function st_polygonfromtext(text)
  returns geometry
immutable
language sql
as $$
SELECT public.ST_PolyFromText($1)
$$;

