create function raster_overlap(raster, raster)
  returns boolean
immutable
language sql
as $$
select $1::geometry OPERATOR(public.&&) $2::geometry
$$;

