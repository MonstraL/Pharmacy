create function st_distance(geography, geography, boolean)
  returns double precision
immutable
language sql
as $$
SELECT public._ST_Distance($1, $2, 0.0, $3)
$$;

