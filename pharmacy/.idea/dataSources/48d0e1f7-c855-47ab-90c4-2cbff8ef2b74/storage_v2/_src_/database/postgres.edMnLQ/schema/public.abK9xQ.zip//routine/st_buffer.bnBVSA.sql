create function st_buffer(geography, double precision, integer)
  returns geography
immutable
language sql
as $$
SELECT public.geography(public.ST_Transform(public.ST_Buffer(public.ST_Transform(public.geometry($1), public._ST_BestSRID($1)), $2, $3), 4326))
$$;

