create function st_setvalue(rast raster, geom geometry, newvalue double precision)
  returns raster
immutable
language sql
as $$
SELECT public.ST_setvalues($1, 1, ARRAY[ROW($2, $3)]::geomval[], FALSE)
$$;

