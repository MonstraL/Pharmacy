create function dropgeometrytable(table_name character varying)
  returns text
language sql
as $$
SELECT public.DropGeometryTable('','',$1)
$$;

