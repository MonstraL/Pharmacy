create function updategeometrysrid(character varying, character varying, integer)
  returns text
language plpgsql
as $$
DECLARE
	ret  text;
BEGIN
	SELECT public.UpdateGeometrySRID('','',$1,$2,$3) into ret;
	RETURN ret;
END;
$$;

