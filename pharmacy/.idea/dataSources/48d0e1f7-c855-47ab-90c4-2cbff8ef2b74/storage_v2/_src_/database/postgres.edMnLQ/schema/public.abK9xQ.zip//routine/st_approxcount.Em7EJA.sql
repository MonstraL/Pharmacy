create function st_approxcount(rast raster, nband integer, sample_percent double precision)
  returns bigint
immutable
language sql
as $$
SELECT public._ST_count($1, $2, TRUE, $3)
$$;

