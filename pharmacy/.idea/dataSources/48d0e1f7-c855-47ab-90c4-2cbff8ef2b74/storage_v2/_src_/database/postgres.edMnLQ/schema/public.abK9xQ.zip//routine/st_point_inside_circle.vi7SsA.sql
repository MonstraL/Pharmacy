create function st_point_inside_circle(geometry, double precision, double precision, double precision)
  returns boolean
immutable
language sql
as $$
SELECT public._postgis_deprecate('ST_Point_Inside_Circle', 'ST_PointInsideCircle', '2.2.0');
    SELECT public.ST_PointInsideCircle($1,$2,$3,$4);
$$;

