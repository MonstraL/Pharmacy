create function contains_2d(geometry, box2df)
  returns boolean
immutable
language sql
as $$
SELECT $2 OPERATOR(public.@) $1;
$$;

