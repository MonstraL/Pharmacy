create function st_mpolyfromwkb(bytea)
  returns geometry
immutable
language sql
as $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

