create function st_multipolygonfromtext(text)
  returns geometry
immutable
language sql
as $$
SELECT public.ST_MPolyFromText($1)
$$;

