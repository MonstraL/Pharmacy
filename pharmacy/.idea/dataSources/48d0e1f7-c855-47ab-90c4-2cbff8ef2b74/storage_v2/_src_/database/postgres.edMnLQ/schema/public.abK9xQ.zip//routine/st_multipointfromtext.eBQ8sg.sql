create function st_multipointfromtext(text)
  returns geometry
immutable
language sql
as $$
SELECT public.ST_MPointFromText($1)
$$;

