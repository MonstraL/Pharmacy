create function "_st_distanceuncached"(geography, geography, boolean)
  returns double precision
immutable
language sql
as $$
SELECT public._ST_DistanceUnCached($1, $2, 0.0, $3)
$$;

