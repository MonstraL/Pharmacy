create function st_rastertoworldcoord(rast raster, columnx integer, rowy integer, OUT longitude double precision, OUT latitude double precision)
  returns record
immutable
language sql
as $$
SELECT longitude, latitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;

