create function st_curvetoline(geometry, integer)
  returns geometry
immutable
language sql
as $$
SELECT ST_CurveToLine($1, $2::float8, 0, 0)
$$;

