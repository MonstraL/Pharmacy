create function dropgeometrytable(schema_name character varying, table_name character varying)
  returns text
language sql
as $$
SELECT public.DropGeometryTable('',$1,$2)
$$;

