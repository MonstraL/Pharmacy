create function st_polygonfromtext(text, integer)
  returns geometry
immutable
language sql
as $$
SELECT public.ST_PolyFromText($1, $2)
$$;

