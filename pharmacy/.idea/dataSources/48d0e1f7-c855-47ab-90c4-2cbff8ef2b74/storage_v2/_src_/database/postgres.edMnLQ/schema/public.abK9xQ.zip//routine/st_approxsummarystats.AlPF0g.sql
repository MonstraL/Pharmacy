create function st_approxsummarystats(rast raster, exclude_nodata_value boolean, sample_percent double precision DEFAULT 0.1)
  returns summarystats
immutable
language sql
as $$
SELECT public._ST_summarystats($1, 1, $2, $3)
$$;

