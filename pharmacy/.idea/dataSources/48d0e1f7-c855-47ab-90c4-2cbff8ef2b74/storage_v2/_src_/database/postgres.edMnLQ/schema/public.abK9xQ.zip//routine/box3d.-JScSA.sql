create function box3d(raster)
  returns box3d
immutable
language sql
as $$
select box3d( public.ST_convexhull($1))
$$;

