create function st_askml(geom geometry, maxdecimaldigits integer DEFAULT 15)
  returns text
immutable
language sql
as $$
SELECT public._ST_AsKML(2, ST_Transform($1,4326), $2, null);
$$;

