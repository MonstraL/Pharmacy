create function st_pointfromtext(text)
  returns geometry
immutable
language sql
as $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromText($1)) = 'POINT'
	THEN public.ST_GeomFromText($1)
	ELSE NULL END

$$;

