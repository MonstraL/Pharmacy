create function st_value(rast raster, pt geometry, exclude_nodata_value boolean DEFAULT true)
  returns double precision
immutable
language sql
as $$
SELECT public.ST_value($1, 1, $2, $3)
$$;

