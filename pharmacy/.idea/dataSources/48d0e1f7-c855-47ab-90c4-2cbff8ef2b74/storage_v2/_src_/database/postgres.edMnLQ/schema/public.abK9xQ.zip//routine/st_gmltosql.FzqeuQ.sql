create function st_gmltosql(text)
  returns geometry
immutable
language sql
as $$
SELECT public._ST_GeomFromGML($1, 0)
$$;

