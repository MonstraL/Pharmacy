create function st_tile(rast raster, nband integer, width integer, height integer, padwithnodata boolean DEFAULT false, nodataval double precision DEFAULT NULL::double precision) returns SETOF raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_tile($1, $3, $4, ARRAY[$2]::integer[], $5, $6)
$$;
