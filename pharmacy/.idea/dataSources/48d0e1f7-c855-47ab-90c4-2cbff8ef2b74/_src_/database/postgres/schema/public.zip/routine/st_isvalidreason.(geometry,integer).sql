create function st_isvalidreason(geometry, integer) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE WHEN valid THEN 'Valid Geometry' ELSE reason END FROM (
	SELECT (public.ST_isValidDetail($1, $2)).*
) foo

$$;
