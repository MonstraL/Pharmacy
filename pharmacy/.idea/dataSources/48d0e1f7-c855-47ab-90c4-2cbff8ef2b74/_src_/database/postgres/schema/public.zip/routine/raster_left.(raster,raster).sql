create function raster_left(raster, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry << $2::geometry
$$;
