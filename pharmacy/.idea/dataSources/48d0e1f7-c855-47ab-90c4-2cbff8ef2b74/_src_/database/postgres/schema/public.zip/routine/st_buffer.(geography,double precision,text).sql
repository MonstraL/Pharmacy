create function st_buffer(geography, double precision, text) returns geography
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.geography(public.ST_Transform(public.ST_Buffer(public.ST_Transform(public.geometry($1), public._ST_BestSRID($1)), $2, $3), 4326))
$$;
