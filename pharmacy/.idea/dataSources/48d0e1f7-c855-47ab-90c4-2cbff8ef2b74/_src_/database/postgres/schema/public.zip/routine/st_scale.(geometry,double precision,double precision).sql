create function st_scale(geometry, double precision, double precision) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Scale($1, $2, $3, 1)
$$;
