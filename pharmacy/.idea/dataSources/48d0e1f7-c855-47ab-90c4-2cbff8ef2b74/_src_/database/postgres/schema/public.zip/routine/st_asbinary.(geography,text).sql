create function st_asbinary(geography, text) returns bytea
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_AsBinary($1::public.geometry, $2);
$$;
