create function st_count(rast raster, exclude_nodata_value boolean) returns bigint
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public._ST_count($1, 1, $2, 1)
$$;
