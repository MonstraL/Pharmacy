create function postgis_raster_scripts_installed() returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT '2.4.4'::text || ' r' || 16526::text AS version
$$;
