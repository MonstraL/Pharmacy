create function st_buffer(text, double precision, integer) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_Buffer($1::public.geometry, $2, $3);
$$;
