create function raster_overlap(raster, raster) returns boolean
IMMUTABLE
LANGUAGE SQL
AS $$
select $1::geometry OPERATOR(public.&&) $2::geometry
$$;
