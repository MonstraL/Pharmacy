create function st_reclass(rast raster, reclassexpr text, pixeltype text) returns raster
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT st_reclass($1, ROW(1, $2, $3, NULL))
$$;
