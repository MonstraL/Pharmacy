create function st_pointfromwkb(bytea) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'POINT'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;
