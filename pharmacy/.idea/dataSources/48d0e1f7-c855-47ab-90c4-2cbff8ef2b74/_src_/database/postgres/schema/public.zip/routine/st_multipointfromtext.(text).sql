create function st_multipointfromtext(text) returns geometry
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT public.ST_MPointFromText($1)
$$;
